
/*
 Access Modifier	Same Class	Same Package	Different Package (Subclass Only)	Different Package (Non-Subclass)
public					✅ Yes		✅ Yes			✅ Yes								✅ Yes
protected				✅ Yes		✅ Yes			✅ Yes								❌ No
default					✅ Yes		✅ Yes			❌ No								❌ No
private					✅ Yes		❌ No			❌ No								❌ No

Java Element	Default Access Behavior
Class			Accessible only within the same package
Methods			Accessible only within the same package
Variables		Accessible only within the same package
Constructors	Accessible only within the same package

*/