class PP2 
{	
	private int age=20;
	void display()
	{			
		System.out.println(" age is "+age);		
	}	
}
public class PRIVATE_2 
{
	public static void main(String[] args) 
	{
		PP2 s1=new PP2();
		//s1.age=30;   //not possible
		s1.display();
	}	
}
/*class c1
	{
		int age=20;	
		void display()
		{
			System.out.println(" age is "+age);
		}	}
	public class Private_adv {
		public static void main(String[] args) {
			c1 s1=new c1();
		    s1.age=30;
			s1.display();    //age will be 30
		}
	}*/

