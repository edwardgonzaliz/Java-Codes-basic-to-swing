
class PP1 
{
	private int a = 10;
	private void display() 
	{
		System.out.println("value is ...");
	}
}
public class PRIVATE_1 
{
	public static void main(String args[]) 
	{
		PP1 s1 = new PP1();
		//System.out.println(s1.a);    //Compile Time Error
		//s1.display();                //Compile Time Error
	}
}