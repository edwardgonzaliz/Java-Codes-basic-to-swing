/*Dynamic Method Dispatch or Run time polymorphism
In this process, an overridden method is called through the reference variable
of a superclass. 
The determination of the method to be called is based on the object being referred
to by the reference variable.*/
class Run_Poly_child
{  		  
	void run()
	{			  
		System.out.println("HELLO");			  
	}  
}		 
class Run_Poly_DyMDis extends Run_Poly_child{  
	void run()
	{			  
		System.out.println("This is called as UPCASTING");			  
	}  

	public static void main(String args[]){  
		Run_Poly_child c1;
		c1= new Run_Poly_DyMDis();//upcasting  
		//If the reference variable of Parent class refers to the object of Child class
		c1.run();  
	}  		}  