class C_T_P {
	public int add(int a, int b)            // Overloaded instance methods
	{    
		return a + b;
	}
	public int add(int a, int b, int c) {
		return a + b + c;
	}
	public double add(double a, double b) {
		return a + b;
	}
}
public class Compil_T_Poly {
	public static void main(String[] args) {
		C_T_P c1 = new C_T_P();	        
		System.out.println("Sum of 10 and 20: " + c1.add(10, 20)); 				// Calls the method with two integer arguments

		System.out.println("Sum of 10, 20, and 30: " + c1.add(10, 20, 30)); 	// Calls the method with three integer arguments

		System.out.println("Sum of 10.5 and 20.5: " + c1.add(10.5, 20.5)); 		// Calls the method with two double arguments
	}
}
