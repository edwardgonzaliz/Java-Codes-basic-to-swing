//static method overloading
class C_T_P_2 {    
	public static int add(int a, int b) {
		return a + b;
	}    
	public static int add(int a, int b, int c) {
		return a + b + c;
	}    
	public static double add(double a, double b) {
		return a + b;
	}
}
public class Compil_T_Poly_2 {
	public static void main(String[] args) {

		System.out.println("Sum of 10 and 20: " + C_T_P_2.add(10, 20));

		System.out.println("Sum of 10, 20, and 30: " + C_T_P_2.add(10, 20, 30));

		System.out.println("Sum of 10.5 and 20.5: " + C_T_P_2.add(10.5, 20.5));
	}
}
