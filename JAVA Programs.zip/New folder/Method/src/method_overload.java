//By varing arguments
//By varing datatype
import java.util.Scanner;

public class method_overload {
	
		int add(int x, int y)
		{
			int res;
			res=x+y; 
			return res;
		}
		int add(int x, int y,int z)
		{
			int res;
			res=x+y+z;
			return res;
		}
		static double add(double x, double y)
		{
			double res;
			res=x+y;
			return res;
		}	
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			method_overload s1=new method_overload();
			System.out.println("Enter value for a and b");
			int a,b,c,r1,rs;
			a=sc.nextInt();
			b=sc.nextInt();	
			c=sc.nextInt();
			r1=s1.add(a,b);
			System.out.println("result is "+r1);
			rs=s1.add(a,b,c);			
			System.out.println("result is "+rs);
			double resd=method_overload.add(12.5,34.5);
			System.out.println("is"+resd);
			
		}
	}

