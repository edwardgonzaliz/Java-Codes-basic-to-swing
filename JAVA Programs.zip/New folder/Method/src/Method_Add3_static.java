import java.util.*;

public class Method_Add3_static {
	static void add(int x, int y) {
		int res;
		res = x + y;
		System.out.println("result is " + res);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value for a and b");
		int a, b;
		a = sc.nextInt();
		b = sc.nextInt();
		Method_Add3_static.add(a, b);
	}
}
