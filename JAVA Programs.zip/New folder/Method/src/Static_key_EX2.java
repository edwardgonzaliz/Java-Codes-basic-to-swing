class Stud11 {
	int regd;
	String name;
	static String uc;

	Stud11(int r, String n) {
		regd = r;
		name = n;
	}

	void display() {
		System.out.println(regd + " " + name + " " + uc);
	}
}
public class Static_key_EX2 {
	public static void main(String args[]) {
		Stud11 s1 = new Stud11(22001, "AAAAA");
		Stud11 s2 = new Stud11(22002, "BBBBB");
		Stud11 s3 = new Stud11(22003, "CCCCC");
		Stud11.uc = "CSE-44-oopj";

		s1.display();
		s2.display();
		s3.display();
	}
}
/*int regd and String name are non-static instance variables, 
  meaning each instance (object) of Stud11 has its own values for these variables.
   
  static String uc is a static variable shared by all instances of the class. 
  Any changes made to uc through one instance will be reflected across all instances 
  because there is only one copy of this variable.
  
  Static variables are shared among all instances of a class, 
  while non-static variables are unique to each instance.
  
  Changing a static variable affects all objects of the class, 
  In ex, shared uc value across s1, s2, and s3.*/
