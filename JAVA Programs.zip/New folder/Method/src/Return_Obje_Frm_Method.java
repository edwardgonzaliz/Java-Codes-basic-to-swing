//Returning object from Method
class Rect
{
	int len,bred;
	Rect(int l,int b)
	{
		len=l;
		bred=b;
	}
	Rect retobj()
	{
		Rect r1=new Rect(10,20);
		return r1;
	}
}
public class Return_Obje_Frm_Method {

	public static void main(String[] args) {
		Rect ob1=new Rect(40,50);
		System.out.println(ob1.len);
		System.out.println(ob1.bred);
		Rect ob2;
		ob2=ob1.retobj();
		System.out.println(ob2.len);
		System.out.println(ob2.bred);
	}
}
