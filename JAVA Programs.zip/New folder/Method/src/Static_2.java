

	public class Static_2 {
	    int x = 6;  // Non-static variable

	    public static void main(String args[]) {
	        // System.out.println(x);         // This will cause a compilation error
	        Static_1 obj = new Static_1();   // Create an instance of the class
	        System.out.println(obj.x);      // Access the non-static variable via the instance
	    }
	}
