
class Stud12 {
	int regd;
	String name;
	static String un = "ABC";

	Stud12(int r, String n) {
		regd = r;
		name = n;
	}

	void display() {
		System.out.println(regd + " " + name + " " + un);
	}
}

public class Static_key_EX3 {
	public static void main(String args[]) {
		Stud12 s1 = new Stud12(22001, "AAAAA");
		Stud12 s2 = new Stud12(22002, "BBBBB");
		Stud12.un = "KIITUNIV";
		s1.display();
		s2.display();
	}
}