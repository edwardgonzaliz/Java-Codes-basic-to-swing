//Count no. of objects created using static
class SO
{
static int count;
	
	//static int count=0;
	public SO()
	{
		count++;
	}
}
public class obj_cnt_static {

	public static void main(String[] args) {
		SO s1=new SO();
		SO s2=new SO();
		SO s3=new SO();
		SO s4=new SO();
		System.out.println("Updated count is "+SO.count);

	}

}
