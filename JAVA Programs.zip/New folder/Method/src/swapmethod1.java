
import java.util.Scanner;

public class swapmethod1 {
	void swap(int x, int y) {
		int z = 0;
		z = x;
		x = y;
		y = z;
		System.out.println(x);
		System.out.println(y);
	}

	public static void main(String[] args) {
		swapmethod1 obj = new swapmethod1();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter two numbers");
		int a = sc.nextInt();
		int b = sc.nextInt();
		System.out.println(a);
		System.out.println(b);
		obj.swap(a, b);
		System.out.println(a);
		System.out.println(b);

	}

}
