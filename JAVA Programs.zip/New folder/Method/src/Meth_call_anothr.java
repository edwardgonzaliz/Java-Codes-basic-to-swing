import java.util.Scanner;

class room
{
	int l,b;
	void input()
	{
		l=5;
		b=8;
	}
	void calc()
	{
		int ar=b*l;
		//this.disp(ar);  //Both are same
		disp(ar);
	}
	void disp(int ar)
	{
		System.out.println("Area is"+ar);
	}
}
public class Meth_call_anothr {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		room r1=new room();
		r1.input();
		r1.calc();

	}

}
