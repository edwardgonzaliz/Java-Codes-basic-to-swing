import java.util.Scanner;
class student
{
	void sum(int p, int q)
	{
		int r1;
		r1=p+q;
		System.out.println("Sum is "+r1);		
	}
	int sub(int m, int n)
	{
		int r1;
		r1=m-n;
		return r1;		
	}
	void mul(double p, double q)   // Method definition
	{
		double s1;
		s1=p*q;
		System.out.println("Mul is "+s1);
	}
	double mod(double d, double e)
	{
		double d1;
		d1=d%e;
		return d1;
	}
	void revm()  // defimnnnnnnn
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter one number in UR choice ");
		int num1=sc.nextInt();
		int rev=0,sum,r;
		int temp=num1;
		while(num1>0)
		{
			r=num1%10;
			rev=rev*10+r;
			num1=num1/10;			
		}	
		System.out.println("Rev is "+rev);			
	}
}
public class Method1 {
	public static void main(String[] args) {
		student s1 = new student();
		Scanner sc = new Scanner(System.in);
		int a,b;
		System.out.println("Enter value of a and b ");
		a=sc.nextInt();
		b=sc.nextInt();
		s1.sum(a,b);
		int taus=s1.sub(a,b);	
		System.out.println("Sub is "+taus);
		s1.mul(34.3, 55.6);
		double res1=s1.mod(56.3,3.8);
		System.out.println("res1=== "+res1);
		s1.revm();
	}	
	}

