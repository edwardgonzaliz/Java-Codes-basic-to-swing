import java.util.Scanner;

public class Method1_CircleArea {
	public static void main(String[] args) {
		Method1_CircleArea s1 = new Method1_CircleArea();
		Scanner sc = new Scanner(System.in);
		double rad;
		System.out.println("Enter radius to find area");
		rad = sc.nextDouble();
		s1.area(rad);
	}

	void area(double x) {
		double pi = 3.141;
		double ar = pi * x * x;
		System.out.println("The computed area is " + ar);
	}
}
