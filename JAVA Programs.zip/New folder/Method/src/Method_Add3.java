import java.util.Scanner;
public class Method_Add3 {
	int add(int x, int y)
	{
		int res;
		res=x+y;
		return res;
	}
	int asub(int x, int y)
	{
		int res;
		res=x-y;
		return res;
	}
	void amul(int x, int y)
	{
		int res;
		res=x*y;
		System.out.println("Result is ..."+res);
	}	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Method_Add3 s1=new Method_Add3();
		System.out.println("Enter value for a and b");
		int a,b,r1,rs;
		a=sc.nextInt();
		b=sc.nextInt();				
		r1=s1.add(a,b);
		rs=s1.asub(a,b);
		System.out.println("result is "+r1);
		System.out.println("result is "+rs);		
	}
}
