
public class Method_Add1 {
	int a = 5, b = 10, res;

	void add() 
	{     // WRT WA
		res = a + b;
		System.out.println("The result is " + res);
	}

	public static void main(String[] args) {
		Method_Add1 s1 = new Method_Add1();
		s1.add();

	}

}
