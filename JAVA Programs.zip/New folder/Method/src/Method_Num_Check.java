import java.util.Scanner;
public class Method_Num_Check {
	void posnegz(int x) {
		if (x > 0)
			System.out.println("positive");
		else if (x < 0)
			System.out.println("negative");
		else
			System.out.println("zero");
	}
	void evenodd(int x) {
		if (x % 2 == 0)
			System.out.println("even");
		else
			System.out.println("odd");
	}
	void prime(int x) {
		int count = 0;
		for (int i = 1; i <= x; i++) {
			if (x % i == 0)
				count++;
		}
		if (count == 2)
			System.out.println("prime");
		else
			System.out.println("not prime");
	}
	void palindrome(int x) {
		int k = x, rev = 0;
		while (x > 0) {
			int r = x % 10;
			rev = (rev * 10) + r;
			x = x / 10;
		}
		System.out.println("Reverse is" + rev);
		if (rev == k)
			System.out.println("palindrome");
		else
			System.out.println("Not palindrome");
	}
	void armstrong(int x) {
		int k = x, sum = 0;
		while (x > 0) {
			int r = x % 10;
			sum = (r * r * r) + sum;
			x = x / 10;
		}
		if (k == sum)
			System.out.println("Armstrong");
		else
			System.out.println("Not Armstrong");
	}
	public static void main(String[] args) {
		Method_Num_Check obj = new Method_Num_Check();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int a = sc.nextInt();
		obj.posnegz(a);
		// System.out.println(r1);
		obj.evenodd(a);
		// System.out.println(r2);
		obj.prime(a);
		// System.out.println(r3);
		obj.palindrome(a);
		// int r4=obj.palindrome(a);
		// System.out.println(r4);
		obj.armstrong(a);
		// System.out.println(r5);
	}
}
