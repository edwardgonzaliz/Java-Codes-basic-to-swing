import java.util.Scanner;
class Method11
{	
	void add(int x, int y)    // Method Definition    Method Called
	{
		int res=x+y;
		System.out.println("Value of x is "+res);
	}
	int sub(int x, int y)    // Method Definition    Method Called
	{
		int res=x-y;
		return res;		
	}
}
public class mmeth {

	public static void main(String[] args) {
		Method11 s1=new Method11();
		Scanner sc=new Scanner(System.in);
		int a,b;
		System.out.println("Enter value of actual parameters");
		a=sc.nextInt();
		b=sc.nextInt();
		s1.add(a,b);         // Method calling
		int k=s1.sub(a,b);  // Method calling
		System.out.println("Value is..."+k);
		// calling method calls to the called
	}

}
// WithRT  WithoutArgument
                                    // WithRT  WithArgument-----------------------
                                   // without RT with Argument...................
// Without RT Without Argument
