class addition
{
	// Method definition    // Method Called    // Method prototype
	//int add121(int x, int y)
	void add121(int x, int y)
	{
		int z;
		z=x+y;
		//return z;
		System.out.println("The z val is..."+z);
	}
}
public class Meth_EX {

	public static void main(String[] args) {
		addition a1=new addition();
		//int res;
		//res=a1.add121(12,15);  // Method calling
		//System.out.println("The resl val is..."+res);
		a1.add121(12,15);
	}
}
