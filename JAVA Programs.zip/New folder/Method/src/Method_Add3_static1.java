
import java.util.Scanner;

public class Method_Add3_static1 {
	static int add(int x, int y) {
		int res;
		res = x + y;
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value for a and b");
		int a, b;
		a = sc.nextInt();
		b = sc.nextInt();
		int r1=Method_Add3_static1.add(a, b);
		System.out.println("Result is "+r1);
	}
}

