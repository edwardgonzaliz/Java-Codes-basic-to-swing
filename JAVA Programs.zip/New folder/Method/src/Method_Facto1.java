import java.util.*;
public class Method_Facto1 {

	int factorial(int x) {
		int f = 1;
		for (int i = 1; i <= x; i++) 
		{			
			f = f * i;  // f=1  // f=2  // f=6  // f=24 // 120
		}
		return f;  // 120
	}

	public static void main(String[] args) {
		Method_Facto1 obj = new Method_Facto1();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number");
		int a = sc.nextInt();    // 5
		int s = obj.factorial(a);
		System.out.println(s);  // 120
	}
}
