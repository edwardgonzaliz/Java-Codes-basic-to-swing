
public class Method_Add2 
{
	public static void main(String[] args) 
	{
		Method_Add2 s1 = new Method_Add2();
		s1.add();
	}

	void add() 
	{
		int a = 5, b = 10, res;
		res = a + b;
		System.out.println("The result is " + res);
	}

}
