import java.util.Scanner;
public class static_method_ex {
	int x;
	int a = 10;
	int b = 20;
	static int z = 50;
	static int y;

	void add() {
		x = a + b;
		System.out.println("result is " + x);
	}

	static void mul() {
		y = 10 * 6;
		System.out.println("result is " + y);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		static_method_ex s1 = new static_method_ex();
		s1.add();
		static_method_ex.z = 490;
		System.out.println("z value is " + z);
		static_method_ex.mul();
	}
}
