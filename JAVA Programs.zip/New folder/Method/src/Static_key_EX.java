
public class Static_key_EX {
	static int count;
    //int count=0; //1 1 1
	Static_key_EX() {
		count++;
		System.out.println(count);   //1 2 3 
	}

	public static void main(String args[]) {
		Static_key_EX c1 = new Static_key_EX();
		Static_key_EX c2 = new Static_key_EX();
		Static_key_EX c3 = new Static_key_EX();
	}
}
