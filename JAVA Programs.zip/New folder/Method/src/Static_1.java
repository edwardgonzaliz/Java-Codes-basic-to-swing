
/*public class Static_1 {
	int x =5;// cant make static reference to a nonstatic

	public static void main(String args[]) {		
		System.out.println(x);
	}
}*/
//....................................
public class Static_1 {
	static int x = 6;

	public static void main(String args[]) {
		System.out.println(x);
	}
}