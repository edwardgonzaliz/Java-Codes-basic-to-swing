import java.util.Scanner;

public class Method2_CircleArea_returnval {
	public static void main(String[] args) {
		Method2_CircleArea_returnval s1 = new Method2_CircleArea_returnval();
		Scanner sc = new Scanner(System.in);
		double rad, res;
		System.out.println("Enter radius to find area");
		rad = sc.nextDouble();
		res = s1.area(rad);
		System.out.println("The result is " + res);
	}

	double area(double x) {
		double pi = 3.141;
		double ar = pi * x * x;
		return ar;
	}

}
