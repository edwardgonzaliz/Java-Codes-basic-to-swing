import java.util.Scanner;
public class Static_error_1 {
	 // int x; //cant make static reference to a nonstatic field
	static int x;
	void update(int a) {
		x = a;
	}

	static void access() {
		System.out.println("result is " + x);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Static_error_1 s1 = new Static_error_1();
		s1.update(12);
		s1.access();
	}
}
//............................................................................
/*import java.util.Scanner;
public class Static_error_1 {
	int x;            //private int x;    similar work
	void update(int a)
	{
		x=a;
	}
	void access()
	{
		System.out.println("result is " + x);
			
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Static_error_1 s1 = new Static_error_1();
		s1.update(15);
		s1.access();
	}
}*/