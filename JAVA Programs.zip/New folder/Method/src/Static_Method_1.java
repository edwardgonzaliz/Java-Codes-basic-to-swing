
public class Static_Method_1 {

	static int square2(int x) // Method Definition
	{
		return x * x;
	}

	public static void main(String args[]) {
//		Static_Method_1 s1=new Static_Method_1();
//		s1.square(5);
		int res = Static_Method_1.square2(3);
		System.out.println(res);
	}
}
