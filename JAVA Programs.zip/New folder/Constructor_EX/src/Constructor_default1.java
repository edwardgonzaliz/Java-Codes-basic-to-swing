class student 
{
	int age;    // instance members
	String name;  
	student() 
	{
		age = 10;
		name = "KIIT";
	}
	void display1() {
		System.out.println(age + " " + name);
	}
}
public class Constructor_default1 {
	public static void main(String[] args) {
		student s1 = new student();
		s1.display1();
	}}
