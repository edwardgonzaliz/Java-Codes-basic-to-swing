class THIS_C {
	String name;
	int salary;
	
	// Constructor with one parameter
	THIS_C(String name) {
		this(name, 12345); // Calls the constructor with two parameters
	}
	// Constructor with two parameters
	THIS_C(String name, int salary) {
		this.name = name;
		this.salary = salary;
	}

	void display() {
		System.out.println("Name: " + name + ", Salary: " + salary);
	}
}

public class THIS_CON {
	public static void main(String args[]) {
		THIS_C T1 = new THIS_C("KKKK");
		T1.display();
	}
}
