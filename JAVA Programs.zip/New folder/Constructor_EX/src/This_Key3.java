
import java.util.Scanner;

class This_Key3 {
	Scanner input = new Scanner(System.in);
	int rollno, sem;
	String name, branch;

	void This_Key3(String nam, String bnch, int rlno, int sm) {
		this.name = nam;
		this.branch = bnch;
		this.rollno = rlno;
		this.sem = sm;
	}

	void display() {
		System.out.println("Name of the Student:" + name);
		System.out.println("Rollnumber of the Student:" + rollno);
		System.out.println("Sem of the Student:" + sem);
		System.out.println("Branch of the Student:" + branch);
	}

	public static void main(String args[]) {
		This_Key3 s2 = new This_Key3();
		s2.This_Key3("KIIT-SCE", "CSE", 1234, 4);
		s2.display();
	}
}
