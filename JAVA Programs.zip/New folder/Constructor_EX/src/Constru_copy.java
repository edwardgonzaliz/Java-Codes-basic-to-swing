/*In Java, a copy constructor is a special type of constructor 
 that creates an object using another object of the same Java class.
 It returns a duplicate copy of an existing object of the class.*/
public class Constru_copy {
	double len, bred, hei, vol;  // instance members
	Constru_copy(double l, double b, double h) {
		len = l;
		bred = b;
		hei = h;
	}
	// creating a copy constructor
	Constru_copy(Constru_copy s1) {
		len = s1.len;
		bred =s1.bred;
		hei = s1.hei;
	}
	double volcomp() {  // called method
		vol = len * bred * hei;
		return vol;
	}
	public static void main(String args[]) {
		
		Constru_copy r1 = new Constru_copy(4, 5, 6);
		double res=r1.volcomp();
		System.out.println(res);
		//System.out.println("the vol is" + r1.volcomp());		
		// passing the parameters to the copy constructor
		Constru_copy r2 = new Constru_copy(r1);
		System.out.println("the vol is" + r2.volcomp());
	}}
