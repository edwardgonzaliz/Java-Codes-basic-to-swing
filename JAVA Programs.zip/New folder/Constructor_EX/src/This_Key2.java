
import java.util.Scanner;

class This_Key2 {
	Scanner input = new Scanner(System.in);
	int rollno, sem;
	String name, branch;

	 This_Key2(String nm, String bnch, int rln, int sem) {
		this.name = nm;
		this.branch = bnch;
		this.rollno = rln;
		this.sem = sem;
	}

	void display() {
		System.out.println("Name of the Student:" + name);
		System.out.println("Rollnumber of the Student:" + rollno);
		System.out.println("Sem of the Student:" + sem);
		System.out.println("Branch of the Student:" + branch);
	}

	public static void main(String args[]) {
		This_Key2 s1 = new This_Key2("KIIT-SCE", "CSE", 101, 1);
		s1.display();
	}
}
