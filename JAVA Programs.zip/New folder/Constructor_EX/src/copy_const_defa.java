	/*In Java, a copy constructor is a special type of constructor 
	 that creates an object using another object of the same Java class.
	 It returns a duplicate copy of an existing object of the class.*/
	 class Constr_copy {
		double len, bred, hei, vol;
		Constr_copy() {
			len = 5;
			bred = 6;
			hei = 7;
		}
		// creating a copy constructor
		Constr_copy(Constr_copy s1) {
			len = s1.len;
			bred =s1.bred;
			hei = s1.hei;
		}
		double volcomp() {
			vol = len * bred * hei;
			return vol;
		}}
		public class copy_const_defa {
		public static void main(String args[]) {
			Constr_copy r1 = new Constr_copy();
			System.out.println("the vol is" + r1.volcomp());		
			// passing the parameters to the copy constructor
			Constr_copy r2 = new Constr_copy(r1);
			System.out.println("the vol is" + r2.volcomp());
		}}

