/*What is constructor? // default constructor  // Parameterized constructor
A constructor is a special type of member function of a class which initializes
objects of a class.
Constructor is automatically called when object(instance of class) create.
It is special member function of the class because it does not have any 
return type.
In Java, a constructor is a block of codes similar to the method.
It is called when an instance of the class is created. 
At the time of calling constructor, 
memory for the object is allocated in the memory.
It is a special type of method which is used to initialize the object.
Every time an object is created using the new keyword, 
at least one constructor is called.
It calls a default constructor if there is no constructor available in the class. 
In such case, Java compiler provides a default constructor by default.
Constructor has same name as the class itself
Constructors don�t have return type
A constructor is automatically called when an object is created.
If we do not specify a constructor, java compiler generates a 
default constructor for object (expects no parameters and has an empty body).*/