// this refers to the object of the present class	
class one {
	int age, id;
	String name;
	int bal;
	one(int x, int y, String nm, int bl) {
		age = x;
		id = y;
		name = nm;
		bal = bl;
	}
	one(int x, int y, String nm) {
		this(x, y, nm, 987654);
	}
	public void print() {
		System.out.println("values are: " + age + " " + id + " " + name + " " + bal);
	}
}
public class This_Keyword1 {
	public static void main(String[] args) {
		one s1 = new one(18, 1234, "KIIT-SCE-CSE-10-47");
		s1.print();
	}}
