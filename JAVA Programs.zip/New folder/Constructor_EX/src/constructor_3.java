// ctrl shift f ....for indention
public class constructor_3 {

	double len, bred, hei, vol;

	constructor_3(double l, double b, double h) {
		len = l;
		bred = b;
		hei = h;

	}

	double volcomp() {
		vol = len * bred * hei;
		return vol;
	}

	public static void main(String args[]) {
		constructor_3 r1 = new constructor_3(4, 5, 6);
		System.out.println("the vol is" + r1.volcomp());
	}
}
