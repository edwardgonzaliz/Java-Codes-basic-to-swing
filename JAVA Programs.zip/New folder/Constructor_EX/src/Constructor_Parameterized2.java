public class Constructor_Parameterized2 {
		int age;
		String name;

		Constructor_Parameterized2(int ab, String nm ) {
			age = ab;
			name = nm;
		}

		void display() {
			System.out.println(age + " " + name);
		}

	public static void main(String[] args) {
		Constructor_Parameterized2 s1 = new Constructor_Parameterized2(44, "KIIT");
		s1.display();

	}

}
