import java.util.Scanner;
public class switch_vowel {
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);		
		String ch;		
		System.out.println("Enter u r char");
		ch=sc.next();		
		switch(ch)
		{
		case "A":
		case "a":
			System.out.println("Char ia a vowel");
			break;
		case "E":
		case "e":
			System.out.println("Char ia a vowel");
			break;		
		default:
				System.out.println("Not a vowel");
		}
	}
}
