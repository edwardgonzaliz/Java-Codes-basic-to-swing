// this refers to the object of the present class
class this_1 {
	 int x;

	this_1() {
		
		this(24);      // call present class parame const and send 24
		this.print();  // call present class method
	}

	this_1(int y) {
		this.x = y;
	}

	void print() {   // called method
		System.out.println(" x=" + x);
	}
}

public class This_Keyword {

	public static void main(String[] args) {
		this_1 s1 = new this_1();
	}
}
