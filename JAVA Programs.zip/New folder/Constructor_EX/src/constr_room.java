import java.util.Scanner;
public class constr_room {	
		double len,bred,hei,vol;  // instance member
		constr_room()
		{			
		}
		constr_room(double l,double b,double h)
		{
			len=l;
			bred=b;
			hei=h;			
		}
		double volcomp()
		{
		vol=len*bred*hei;
		return vol;
		} 
		public static void main(String args[])
		{ 
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter value of a1 b1 and c1");
			double a1=sc.nextDouble();
			double b1=sc.nextDouble();
			double c1=sc.nextDouble();			
			constr_room r1=new constr_room(a1,b1,c1);
			double res1=r1.volcomp(); // calling method
			System.out.println("The result is"+res1);		
		//System.out.println("the vol is"+r1.volcomp());
		}		}
