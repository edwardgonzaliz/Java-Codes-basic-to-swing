 class CpyCon_Pm {
	    int regd;
	    String name;

	    // Parameterized constructor
	    CpyCon_Pm(int regd, String name) {
	        this.regd = regd;
	        this.name = name;
	    }

	    // Copy constructor
	    CpyCon_Pm(CpyCon_Pm s) {
	        this.regd = s.regd;
	        this.name = s.name;
	    }

	    // Method to display student details
	    void display() {
	        System.out.println("Regd: " + regd + ", Name: " + name);
	    }
	}

	public class CpyCon_Param {
	    public static void main(String args[]) {
	        // Creating object using parameterized constructor
	    	CpyCon_Pm s1 = new CpyCon_Pm(101, "Alice");

	        // Creating object using copy constructor
	    	CpyCon_Pm s2 = new CpyCon_Pm(s1);

	        // Displaying details of both objects
	        s1.display();
	        s2.display();
	    }
	}