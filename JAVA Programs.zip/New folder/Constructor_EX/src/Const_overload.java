import java.util.Scanner;
class stu {
	int age, id;  //instance members
	double mark;   // instance member
	stu() {
		Scanner sc1=new Scanner(System.in);
		age = 10;
		id = 101;	}
	stu(int x, int y,double m) {
		age = x;
		id = y;
		mark=m;	}
	void display() {   // called method
		System.out.println(age + " " + id);	}
	void display1() {
		System.out.println(age + " " + id+ " "+mark);
	} }
public class Const_overload {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		stu s1 = new stu();
		s1.display();  // calling method
		System.out.println("Enter value for n1, n2 and n3");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		double n3=sc.nextDouble();
		stu s2 = new stu(n1,n2,n3);
		//stu s2 = new stu(20,1234,90.5);
		s2.display1();
	}}
