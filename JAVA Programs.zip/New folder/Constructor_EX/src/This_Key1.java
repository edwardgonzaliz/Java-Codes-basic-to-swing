class common1 {
	static int total_water = 0; // stores in static memory updated value we will fetch
	int cur_level = 0;
	int usage = 0;
	int amount_used = 0;
	int water_filled = 0;

	static void totallevel(int water_filled) {
		total_water = 3 * water_filled;
		System.out.println("Total water filled " + " " + total_water);
	}

	void usageA(int usage) {
		int total_water1 = total_water - usage;
		System.out.println("Water level after usage of A is" + " " + total_water1);
	}

	void usageB(int usage) {
		common1.total_water = 130;
		amount_used = total_water - usage;
		System.out.println("Water level after usage of B is" + " " + amount_used);
		System.out.println("Current water level of the tank is" + "" + amount_used);
	}
}

public class This_Key1 {
	public static void main(String[] args) {

		common1 c = new common1();
		common1.totallevel(50);
		c.usageA(20);
		c.usageB(40);
	}
}
