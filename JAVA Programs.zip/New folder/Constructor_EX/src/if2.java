
public class if2 {

	public static void main(String[] args) {
		//if(1)
			//System.out.println("Hello");
		//if(true)
			//System.out.println("Hello");
		if(5<6)
			System.out.println("Hello");

	}

}
