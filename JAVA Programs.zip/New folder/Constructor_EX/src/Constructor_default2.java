import java.util.Scanner;
class student1 {
	int age;
	String name;
	float mark;
	student1() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age and name ");
		age = sc.nextInt();
		name = sc.next();
	}
	student1(int x, String y, float m) {
		age=x;
		name=y;
		mark=m;
	}
	void display() {
		System.out.println(age + " " + name);
	}	
	
void display1() {
	System.out.println(age + " " + name+ " "+mark);
}	}
public class Constructor_default2 {
	public static void main(String[] args) {
		student1 s1 = new student1();
		s1.display();
		int r1;
		String r2;
		Scanner sc=new Scanner(System.in);
		r1=sc.nextInt();
		r2=sc.next();	
		float r3=sc.nextFloat();
		student1 s2 = new student1(r1,r2, r3);
		s2.display1();
	}}
