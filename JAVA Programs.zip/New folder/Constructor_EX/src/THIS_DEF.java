/* Accessing Instance Variables
this helps distinguish between instance variables and parameters with the same name.

Calling a Constructor from Another Constructor (Constructor Chaining)
this() can be used to call another constructor within the same class.

Returning the Current Class Instance
this can be returned from a method.*/
class THIS_D {
    int id;
    String name;
    // Constructor with parameters
    THIS_D(int id, String name) {
        this.id = id;     // 'this.id' refers to the instance variable
        this.name = name; // 'this.name' refers to the instance variable
    }
    void display() {
        System.out.println("ID: " + id + ", Name: " + name);
    }
}
public class THIS_DEF {
    public static void main(String args[]) {
    	THIS_D s1 = new THIS_D(12345, "KIIT");
        s1.display(); 
    }
}