
	class DefaultValues {
	    int instanceVar;              // Non-static variable
	    static int staticVar;         // Static variable

	    void display() {
	        System.out.println("Default value of instance variable: " + instanceVar);
	        System.out.println("Default value of static variable: " + staticVar);
	    }

	    public static void main(String args[]) {
	        DefaultValues obj = new DefaultValues();
	        obj.display();
	    }
	}