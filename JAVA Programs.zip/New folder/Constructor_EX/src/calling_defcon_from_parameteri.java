
public class calling_defcon_from_parameteri {

	String studName;
	int studAge;
	String activity;

	calling_defcon_from_parameteri() {
		activity = " ACTIVE";
	}

	calling_defcon_from_parameteri(String name, int age) {
		this();
/*
* this is used for calling the default constructor from parameterized constructor
*/
		studName = name;
		studAge = age;
	}

	void display() {
		System.out.println(studName + " -" + studAge + "-" + "activity" + activity);
	}

	public static void main(String args[]) {
		calling_defcon_from_parameteri s1 = new calling_defcon_from_parameteri("Ravi", 20);
		s1.display();
	}
}
