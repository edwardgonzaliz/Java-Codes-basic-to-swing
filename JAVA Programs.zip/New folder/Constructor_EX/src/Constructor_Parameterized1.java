import java.util.Scanner;
class student2 {
	int age;           
	String name;  	

	student2(int a, String b) {
		age = a;           
		name = b;          
	}
	void display() {
		System.out.println(age + " " + name);	
	}
}
public class Constructor_Parameterized1 {
	public static void main(String[] args) {
		student2 s1 = new student2(200, "ooooookkkkk");		
		s1.display();
//		Scanner sc=new Scanner(System.in);
//		int k;
//		String k1;
//		System.out.println(" Enter required constraints");
//		k=sc.nextInt();
//		k1=sc.next();
//		student2 s1 = new student2(k, k1);
//		s1.display();
	}
}
