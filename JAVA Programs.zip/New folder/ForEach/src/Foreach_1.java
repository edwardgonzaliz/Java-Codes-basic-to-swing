//An example of Java for-each loop 
public class Foreach_1 {	 

	public static void main(String args[]){  
		//declaring an array  
		int arr[]={2,4,6,8};  
		//traversing the array with for-each loop  
		for(int i:arr){  
			System.out.println(i);  
		}  
	}   
}  