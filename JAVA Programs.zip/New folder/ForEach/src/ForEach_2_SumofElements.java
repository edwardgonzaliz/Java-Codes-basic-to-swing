
public class ForEach_2_SumofElements {

	public static void main(String args[]){  
		int arr[]={5,10,15,20};  
		int total=0;  
		for(int i:arr){  
			total=total+i;  
		}  
		System.out.println("Total: "+total);  
	}   
}  