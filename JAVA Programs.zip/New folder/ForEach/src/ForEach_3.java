import java.util.Scanner;

public class ForEach_3 {

	public static void main(String[] args) {
		int ar1[] = new int[20]; 		// int a[]; //a=new int[20];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		System.out.println("Enter the elements");
		for (int i = 0; i < n; i++) {
			ar1[i] = sc.nextInt();
		}
		int sum_tot=0;  
		for(int i:ar1){  
			sum_tot=sum_tot+i;  
		}  
		System.out.println("Total: "+sum_tot);  

	}

}
