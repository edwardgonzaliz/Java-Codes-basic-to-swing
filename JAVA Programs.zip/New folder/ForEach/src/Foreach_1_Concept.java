
/*It provides an alternative approach to traverse the array or collection in Java. 
  It is mainly used to traverse the array or collection elements. 
  The advantage of the for-each loop is that it eliminates the possibility of bugs and 
  makes the code more readable. 
 
 It is known as the for-each loop because it traverses each element one by one.
 ADVANTAGES
       It makes the code more readable.
       It eliminates the possibility of programming errors.
 SYNTAX
       for(data_type variable : array | collection){  
            //body of for-each loop  
           }  
           //An example of Java for-each loop  
class ForEachExample1{  
  public static void main(String args[]){  
   //declaring an array  
   int arr[]={10,12,14,16};  
   //traversing the array with for-each loop  
   for(int i:arr){  
     System.out.println(i);  
   }  
 }   
}  
 */