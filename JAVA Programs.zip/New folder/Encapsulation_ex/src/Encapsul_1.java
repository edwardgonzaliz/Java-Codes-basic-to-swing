 /* According to encapsulation a class protects its own members. 
 So if same names are used for the members of two diff classes, 
 there will not be any overwriting of data.*/
class st1
{
int id=102;
String nm="KIIT";
void display()
{
	System.out.println(" id & name..."+id +" "+nm);
}}
class st2
{
	int id=104;
	String nm="KIIT1";
	void display()
	{
		System.out.println(" id & name..."+id +" "+nm);
	}}
public class Encapsul_1 {
	public static void main(String[] args) {
		st1 s1=new st1();
		s1.display();
		st2 s2=new st2();
		s2.display();
	}}
