abstract class ebill {	
	protected double cost;
	abstract void getcost();	
	void Totalbill(int units) {
		System.out.print("Bill amount for" + " " + units + " " + "UNITS : ");
		System.out.println(cost * units);
	}}
class commer extends ebill {
	public void getcost() {
		cost = 5;
	}}
class domestic extends ebill {
	public void getcost() {
		cost = 2;
	}}
public class Abstract_Ebill {
	public static void main(String[] args) {
		ebill e1;
		e1 = new commer();
		e1.getcost();
		e1.Totalbill(200);
		e1 = new domestic();
		e1.getcost();
		e1.Totalbill(300);
		/*
		 * commer c1=new commer(); c1.getcost(); c1.Totalbill(100); domestic d1=new
		 * domestic(); d1.getcost(); d1.Totalbill(100);
		 */
	}
}
