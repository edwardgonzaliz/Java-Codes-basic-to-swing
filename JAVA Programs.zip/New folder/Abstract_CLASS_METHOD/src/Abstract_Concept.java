
/*abstract class- 
	-A class which is declared with the abstract keyword
	 is known as an abstract class in Java 
	 It can have abstract and non-abstract methods (method with the body)
 
	
abstract method-
	-A method which is declared as abstract and 
	 does not have implementation is known as an abstract method
	-It is a method without method body
	-It is required when the same method has to perform different 
	 tasks depending on the object calling it
	 
	->Both the abstract class and abstract method should be 
	 declared by using the keyword abstract <-
*/