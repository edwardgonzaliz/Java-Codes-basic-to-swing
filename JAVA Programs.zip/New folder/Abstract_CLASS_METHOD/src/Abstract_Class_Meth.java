/*WAP where the abstract class Test_Abstract has one abstract
  method which has got various implementations in subclasses */
abstract class Test_Abstract {
	abstract void calcu(double x);}
class Square extends Test_Abstract {
	void calcu(double x) {
		double sq = x * x;
		System.out.println("square is" + sq);
	}}
class Sqroot extends Test_Abstract {
	void calcu(double x) {
		double st = Math.sqrt(x);
		System.out.println("square root is" + st);
	}}
class Cube extends Test_Abstract {
	void calcu(double x) {
		double cu = x * x * x;
		System.out.println("Cube is" + cu);
	}}
public class Abstract_Class_Meth {
	public static void main(String[] args) {
		//		Square s1 = new Square();		//		s1.calcu(5); 		//		Sqroot s2 = new Sqroot();		//		s2.calcu(25); 		//		Cube s3 = new Cube();		// 	s3.calcu(4);
		Test_Abstract T1;
		T1 = new Square();
		T1.calcu(5);
		T1 = new Sqroot();
		T1.calcu(25);
		T1 = new Cube();
		T1.calcu(4);
	}}
