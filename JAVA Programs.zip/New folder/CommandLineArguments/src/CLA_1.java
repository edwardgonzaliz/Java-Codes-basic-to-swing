
public class CLA_1 {
	public static void main(String[] args)
	{
	System.out.println(args[0]);
	System.out.println(args[1]);
	System.out.println(args[2]);
	}
	}
	
// for compile  : javac CLA_1.java
// for execution: java CLA_1 I am 12345

// I am 12345