
public class sum_nos_cla {

	public static void main(String[] args) {
		int sum=0;
		System.out.println("calculate sum of inputted integers: ");
		for (int i=0;i<args.length;i++)
		{
			sum=sum+Integer.parseInt(args[i]);
			
		}		
		System.out.println("SUM IS " + sum);
	}
}
//notepad    fn.java  save
// cd Desktop
// javac fn.java
//java fn 1 2 3 4 5 6 7 8 9 10