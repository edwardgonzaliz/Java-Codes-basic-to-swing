
public class CLA_4 {

	public static void main(String[] args) {

		int x = Integer.parseInt(args[0]); // converts string to integer

		double y = Double.parseDouble(args[1]);
		String s = args[2]; // no need of parse, its already string
		// System.out.println("String: "+args[2]);
		System.out.println("String: " + s);
		System.out.println("Double: " + y);
		System.out.println("Int: " + x);
	}
}
