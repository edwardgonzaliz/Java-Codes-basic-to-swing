// Inputs from command prompt
import java.util.Scanner;

public class CLA_2 {

	public static void main(String[] args) {
		int rollno = Integer.parseInt(args[0]);
		int sem = Integer.parseInt(args[1]);
		String name = args[2];
		String branch = args[3];

		System.out.println("RollNum:" + rollno);
		System.out.println("\nBranch:" + branch);
		System.out.println("\nSem:" + sem);
		System.out.println("\nName:" + name);

	}
}

// Output
// Javac filename.java
// Java  filename is 029 8 BBSRRR cse
