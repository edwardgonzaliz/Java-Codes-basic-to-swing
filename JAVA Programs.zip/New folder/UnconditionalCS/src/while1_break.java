
public class while1_break {

	public static void main(String[] args) {
//		int i=1;
//		while(i<=5)
//		{
//			if(i==3)
//				break;
//			System.out.println(+i);
//			i++;
//		}
//		int i=1;
//		while(true)
//		{
//			if(i==5)
//				break;
//			System.out.println(+i);
//			i++;
//		}
		// Infinite Loop
		int i=10;
		while(true)
		{
			System.out.println("num is "+i);
			if(i==15)
				break;
			i=i+1;
		}
	}
}
