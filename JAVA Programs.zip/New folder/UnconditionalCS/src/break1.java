
public class break1 {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++)
		{
			if(i%3==0)
				//break;
			    continue;
				System.out.println("num is "+i);
		}
		System.out.println("Hello");
	}
}
