
public class for1_break {

	public static void main(String[] args) {
//		int i=1;
//		for( ; ; )
//		{
//			if(i==5)
//				break;
//			System.out.println(i);
//			i++; //i=i+1;
		
		int i=1;
		for( ; ; )
		{
			if(i==5)
			continue;
			System.out.println("PRINT NUM "+i);
			i++;	
	}
	}
}
