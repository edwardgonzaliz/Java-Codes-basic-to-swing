
public class Break_Continue {
	public static void main(String[] args) {
		for(int i=1;i<=10;i++)
		{
			if(i%3==0)
			{
				System.out.println(" num is "+i);				
				//continue;
			break;
			}			
		}
	}
}
