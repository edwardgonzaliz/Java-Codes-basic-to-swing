// Multilevel Inheritance with default constructor
class A 
{	int mark1;
	A() 
	{
		mark1 = 94;
	}}
class B extends A 
{
	int mark2;
	B() 
	{
		mark2 = 96;
	}}
class C extends B 
{	int mark3;
	C() 
	{
		mark3 = 98;
	}
	/*void display() 
	{
		System.out.println("Marks are " + mark1 + " " + mark2 + " " + mark3);
	}*/
}
	class D extends C 
	{	int mark4;
		D() 
		{
			mark4 = 99;
		}
		void display() 
		{
			System.out.println("Marks are " + mark1 + " " + mark2 + " " + mark3+" " + mark4);
		}
	}

public class Inher_Multilev_1 
{
	public static void main(String[] args) 
	{
		D c1 = new D();
		c1.display();
	}
	}
