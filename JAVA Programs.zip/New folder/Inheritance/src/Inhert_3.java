//Parameterized constructor of super class is not available directly to the child class by default
class teacher4 
{
	int age;
	teacher4(int x) 
	{
		age = x;
	}
}
class student4 extends teacher4 
{
	int id;

	student4(int y, int z) 
	{
		super(y);
		id = z;
	}
	void display() 
	{
		System.out.println(age + " " + id);
	}
}
public class Inhert_3 {

	public static void main(String[] args) {
		student4 s1 = new student4(20, 50);
		s1.display();
	}
}