	import java.util.Scanner;
	class Student {
	    int roll;
	    String name;
	    double cgpa;

	    Student(int roll, String name, double cgpa) {
	        this.roll = roll;
	        this.name = name;
	        this.cgpa = cgpa;
	    }

	    void display() {
	        System.out.println("Roll: " + roll);
	        System.out.println("Name: " + name);
	        System.out.println("CGPA: " + cgpa);
	    }
	}

	public class Lab4_Assignment {

	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);

	        // Get the number of students
	        System.out.print("Enter the number of students: ");
	        int n = in.nextInt();

	        // Create an array to store students
	        Student students[] = new Student[n];

	        // Input details for each student
	        for (int i = 0; i < n; i++) {
	            System.out.println("Enter details for student " + (i + 1) + ":");
	            System.out.print("Roll: ");
	            int roll = in.nextInt();
	            in.nextLine(); // Consume the newline character
	            System.out.print("Name: ");
	            String name = in.nextLine();
	            System.out.print("CGPA: ");
	            double cgpa = in.nextDouble();

	            students[i] = new Student(roll, name, cgpa);
	        }

	        // Find the student with the lowest CGPA
	        double lowestCGPA = Double.MAX_VALUE;
	        int lowestIndex = -1;
	        for (int i = 0; i < n; i++) {
	            if (students[i].cgpa < lowestCGPA) {
	                lowestCGPA = students[i].cgpa;
	                lowestIndex = i;
	            }
	        }

	        // Display the details of all students
	        System.out.println("\nStudent Details:");
	        for (Student student : students) {
	            student.display();
	        }

	        // Display the name of the student with the lowest CGPA
	        if (lowestIndex != -1) {
	            System.out.println("\nStudent with the lowest CGPA: " + students[lowestIndex].name);
	        } else {
	            System.out.println("\nNo students found.");
	        }

	       in.close();
	    }
	}