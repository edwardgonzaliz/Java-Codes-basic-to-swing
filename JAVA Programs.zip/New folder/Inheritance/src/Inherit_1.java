class Teacher3 
{	int id;
	String name;
	int age;
	void input() 
	{		id = 123;
		name = "KIIT";
		age = 30;	}	}
class Student3 extends Teacher3 
{	int mark;
	void input() 
	{		mark = 90;		}
	void display() 	{
		System.out.println(id + " " + name + " " + age + " " + mark);	}}
public class Inherit_1 
{	public static void main(String[] args) 
	{		Student3 s1 = new Student3();
		s1.input();			
		s1.display();
	}}
