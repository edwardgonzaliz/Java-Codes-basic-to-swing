		class H1 
		{	int mark1;
			H1() 
			{
				mark1 = 94;
			}}
		class H2 extends H1 
		{
			int mark2;
			H2() 
			{
				mark2 = 96;
			}}
		class H3 extends H1 
		{	int mark3;
			H3() 
			{
				mark3 = 98;
			}
			void display() 
			{
				//System.out.println("Marks are " + mark1 + " " + mark2 + " " + mark3);
				System.out.println("Marks are " + mark1 + " " + " " + mark3);
			}}
		public class Hierarchical_Inherit {
			public static void main(String[] args) {
				H3 h1 = new H3();
				h1.display();
			}}

	
