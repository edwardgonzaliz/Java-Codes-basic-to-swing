	class Person {
	    String name;
	    Person(String name) {
	        this.name = name;
	    }
	    void displayInfo() {
	        System.out.println("Name: " + name);
	    }
	}
	class Employee extends Person {
	    double salary;

	    Employee(String name, double salary) {
	        super(name);  // Calls the Person constructor
	        this.salary = salary;
	    }
	        void displayInfo() {
	        super.displayInfo();  // Calls Person's displayInfo()
	        System.out.println("Salary: " + salary);
	    }
	}
	public class Constr_Chaining_Single {
	    public static void main(String[] args) {
	        Employee emp = new Employee("Alice", 50000);
	        emp.displayInfo();
	    }
	}