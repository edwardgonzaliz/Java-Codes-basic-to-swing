// Method overriding
class Teacher1 
{
	int id;
	String name;
	int age;
	void input() 
	{
		id = 6666;
		name = "KIIT";
		age = 50;
	}
	void display() 
	{
		System.out.println(id + " " + name + " " + age);
	}
}
class Student1 extends Teacher1 {
	int mark;
	void input() 
	{
		mark = 90;
	}
	void display() 
	{
		System.out.println(id + " " + name + " " + age + " " + mark);
	}
}
public class Inheritance_1_Single {
	public static void main(String[] args) {
		Student1 s1 = new Student1();
		
		s1.input();
		s1.display();
		
		  //Teacher1 s2=new Teacher1(); s2.input(); s2.display();
		 
	}
}
