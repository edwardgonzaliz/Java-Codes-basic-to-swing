class Animal {
	void eat() {
		System.out.println("Animal is eating.");
	}
}
class Mammal extends Animal {
	void walk() {
		System.out.println("Mammal is walking.");
	}
}
class Dog extends Mammal {
	void eat() {
		super.eat();  // Calls the eat() method in Animal
		System.out.println("Dog is eating.");
	}
}
public class Multilev_Override1 {
	public static void main(String[] args) {
		Dog d1 = new Dog();
		d1.eat();   // Outputs both Animal and Dog eat() methods
		d1.walk();  // Outputs walk() from Mammal
	}
}
