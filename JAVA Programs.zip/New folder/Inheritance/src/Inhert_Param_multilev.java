// Multilevel Inheritance with Parameterized constructor	
class A1 
	{		int mark1,cnt;
		A1(int x) 
		{
			mark1 = x;
		}	
		void disp()
		{
			cnt=mark1+5;
			System.out.println(" "+cnt);
		}
		}
	class B1 extends A1 
	{		int mark2;
		B1(int x, int y) 
		{
			super(x);
			mark2 = y;
		}	}
	class C1 extends B1 
	{		int mark3;
		C1(int x, int y, int z) 
		{
			super(x,y);
			mark3 = z;
		}
		void display() 
		{
			System.out.println("Marks are " + mark1 + " " + mark2 + " " + mark3);
		}	}
	public class Inhert_Param_multilev {
		public static void main(String[] args) {
			C1 c1 = new C1(94,96,98);
			c1.display();
			A1 a1 = new A1(9);
			a1.disp();
		}	}
