// Parameterized constructor of super class is not available directly to the child class by default
class Teacher5 
{
	int id;
	String name;
	int age;

	Teacher5(int x, String n, int a) {
		id = x;
		name = n;
		age = a;
	}
}
class Student5 extends Teacher5 {
	int mark, nos;
	Student5(int m, int ns, int x, String n, int a)
	// Student5(int x,String n,int a)
	{
		super(x, n, a);
		mark = m;
		nos = ns;
		// mark=88;
		// nos=99;
	}
	void display() {
		System.out.println(mark + " " + nos + " " + id + " " + name + " " + age);
	}
}
public class Inheri_4 {
	public static void main(String[] args) {
		Student5 s1 = new Student5(100, 6, 112360908, "ii", 34);
		s1.display();
		// Student5 s1=new Student5(30,"ii",40);
		
	}
}
