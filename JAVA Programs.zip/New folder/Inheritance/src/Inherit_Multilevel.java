class shape
{	protected double length;
	shape(double l)
	{		length=l;
	}}
class square extends shape
{	square(double l)
	{		super(l);
	}
	void area()
	{		double ar=length*length;
		System.out.println("area of square is"+ar);
	}}
class rectangle extends square
{	double bred;
	rectangle(double l,double b)
	{		super(l);
		bred=b;		
	}	void area()
	{		double ar1=length*bred;
		System.out.println("area of rectangle is"+ar1);
	}}
class room extends shape 
{	double height;
	room(double l,double h)
	{		super(l);		
		height=h;		
	}	void area()
	{		double ar2=length*height;
		System.out.println("volume of room is"+ar2);
	}}
public class Inherit_Multilevel {
	public static void main(String[] args) {
		square sq=new square(5);
		sq.area();
		rectangle re=new rectangle(5,4);
		re.area();
		room ro=new room(5,3);
		ro.area();
	}
}

