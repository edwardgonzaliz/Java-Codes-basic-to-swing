// Solution to method overriding
class Teacher2
{	int id;
	String name;
	int age;
	int mark;
	void input()
	{		id=1234;
		name="KIIT";
		age=20;
		mark=100;
	}}
class Student2 extends Teacher2
{	int mark;
		void input()
	{		super.input();
		mark=90;	}
void display()
{	System.out.println(id +" "+ name +" "+ age +" "+mark);}}
public class Inheritance_single_2 {
	public static void main(String[] args) {
		Student2 s1=new Student2();
		s1.input();
		s1.display();
	}}

