class Te
{		int id;
	String name;
	int age;
	void input()	{	
		id=1234;
		name="KIIT";
		age=20;		}
	void display()
	{			System.out.println(id +" "+ name +" "+ age );		}   }
class St 
{	int id;
	String name;
	int age;
	int mark;
	void input()
	{		id=4321;
		name="KIIS";
		age=18;  	}
	void display()
	{				System.out.println(id +" "+ name +" "+ age +" "+mark);  	}
}
public class Inherit_0 
{	public static void main(String[] args) 
	{		St s1=new St();
		Te s2=new Te();		
		s2.input();
		s2.display();
		s1.input();
		s1.display();
	}}



