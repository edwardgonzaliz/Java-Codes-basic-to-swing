	class AA
	{	   public void methodA()
	   {	      System.out.println("method of Class A");		   } 	}
	class BB extends AA
	{	   public void methodB()
	   {	      System.out.println("method of Class B");		   } 	}
	class CC extends AA
	{	  public void methodC()
	  {	     System.out.println("method of Class C");		  }		}
	class DD extends AA
	{	  public void methodD()
	  {	     System.out.println("method of Class D");		  } 	}
	class Hierac_2
	{	  public static void main(String args[])		  {
	     BB obj1 = new BB();
	     CC obj2 = new CC();
	     DD obj3 = new DD();
	     //All classes can access the method of class A
	     obj1.methodA();
	     obj2.methodA();
	     obj3.methodA();
	  }
	}