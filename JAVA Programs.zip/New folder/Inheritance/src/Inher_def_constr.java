// default constructor of super class is available to the child class by default
class Teach1 {
	int id;
	String name;
	int age;
	Teach1() {
		id = 8888;
		name = "KIIT";
		age = 50;
	}
	//void display() {
		//System.out.println(id + " " + name + " " + age);
	//}
}
class Studen1 extends Teach1 {
	int mark;
	Studen1() {
		mark = 90;
	}
	void display() {
		System.out.println(id + " " + name + " " + age + " " + mark);
	}
}
public class Inher_def_constr {
	public static void main(String[] args) {
		Studen1 s1 = new Studen1();
		s1.display();		
	}
}
