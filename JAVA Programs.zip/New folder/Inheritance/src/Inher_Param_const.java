// Parameterized constructor of super class is not available directly to the child class by default
class Teach2 {
	int id;
	String name;
	int age;
	Teach2(int x, String nm, int y) 
	{
		id = x;
		name = nm;
		age = y;
	}}
class Studen2 extends Teach2 {
	int mark;

	Studen2(int x, String nm, int y, int mk) {
		super(x, nm, y);
		mark = mk;
	}
	void display() {
		System.out.println(id + " " + name + " " + age + " " + mark);
	}}
public class Inher_Param_const {
	public static void main(String[] args) {
		Studen2 s1 = new Studen2(12345, "B2PC", 20, 99);
		s1.display();
	}}