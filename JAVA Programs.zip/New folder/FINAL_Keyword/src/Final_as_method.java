//If you make any method as final, you cannot override it.
class Final_as_method1
{  
	final void over_ride()
	{
		System.out.println("Overridimg");
	}  
}  
class Final_as_method extends Final_as_method1
{  
	//void over_ride()  //can not override final method so compile time error
	{
		System.out.println("Overriding Example");
	}  

	public static void main(String args[])
	{  
		Final_as_method  f1= new Final_as_method ();  
		f1.over_ride();
		//Final_as_method1.over_ride();
	}  
}  


