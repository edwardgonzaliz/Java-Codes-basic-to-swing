//A static final variable that is not initialized at the time of declaration is known as
//static blank final variable. It can be initialized only in static block.   
class static_final_var
{  
	static final int roll;    //static blank final variable  
	static
	{ 
		roll=10;
	}  
	public static void main(String args[]){  
		System.out.println(static_final_var.roll);  
	}  }
/*class static_final_var {
int instanceVar = 10; // Instance variable
static int staticVar = 20; // Static variable
static void display() {
//static  {
    // Cannot access instanceVar directly, but can access staticVar
    System.out.println("Static variable: " + staticVar);
    // System.out.println("Instance variable: " + instanceVar); // Error
}
public static void main(String args[]){  
	System.out.println(static_final_var.staticVar);
	//static_final_var s1=new static_final_var();
	//System.out.println(s1.instanceVar);
} 
}*/
/*
A static method is class-level; it can be called without creating an object of the class.

Memory Efficiency:
Since static methods are loaded once per class (at class loading time), 
they save memory by not being tied to specific instances.
This is ideal for methods that do not rely on instance-specific data.

No Instance Dependency:
A static method cannot access instance variables or instance methods directly 
because it is not tied to any specific object.

Reasons for static in main():

Entry Point:
The JVM calls the main() method directly without creating an object of the class. 
Declaring it static ensures it can be called without instantiating the class.
No Instance Needed:
As the entry point for execution, the main() method must not depend on any instance-specific 
data or behavior.
Efficient Initialization:
The static keyword ensures main() is loaded and executed once, as a part of the class itself.
*/