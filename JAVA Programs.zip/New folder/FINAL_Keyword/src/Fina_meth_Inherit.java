//final method can be inherited but you cannot override it. 
class Fina_meth_Inherit1
{  
	final void run()
	{
		System.out.println("Successfully Inherited...");
	}  
}

class Fina_meth_Inherit extends Fina_meth_Inherit1
{  
	public static void main(String args[])
	{  
		//new Fina_meth_Inherit().run();  
		Fina_meth_Inherit f2=new Fina_meth_Inherit();
		f2.run();
	}  
}  