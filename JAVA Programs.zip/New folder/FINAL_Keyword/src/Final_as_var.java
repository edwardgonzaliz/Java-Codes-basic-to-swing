//If you make any variable as final, you cannot change the value of final 
//variable(It will be constant).
public class Final_as_var 
{	
	final int roll=10;		//final variable  
	void student_roll()
	{  
		//roll=20; 
		//System.out.println(roll); 
	}  
	public static void main(String args[])
	{  
		Final_as_var f1=new  Final_as_var();  
		f1.student_roll();  
	}  
}
//compile time error as changing to 20
