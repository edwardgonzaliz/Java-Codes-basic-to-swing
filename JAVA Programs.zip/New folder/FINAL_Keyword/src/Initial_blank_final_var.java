//Can we initialize blank final variable?
//Yes, but only in constructor. 

class Initial_blank_final_var
{  
	final int roll;		//blank final variable  

	Initial_blank_final_var()
	{  		 
		roll=10;
		System.out.println(roll);  
	}  

	public static void main(String args[])
	{  
		Initial_blank_final_var f1=new Initial_blank_final_var();  
	}  
}  
