//What is final parameter?
//If you declare any parameter as final, you cannot change the value of it.
class Final_param
{  
	int cube( final int n)
	{ 
		// System.out.println(" is :"+n);
		//n=n+2;//can't be changed as n is final  

		return n; //valid
	}  
	public static void main(String args[])
	{  
		Final_param b=new Final_param();  
		int k=b.cube(5);  
		System.out.println(" is :"+k);
	}  
}  