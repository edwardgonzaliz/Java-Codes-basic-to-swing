//If you make any class as final, you cannot extend it.
class Final_as_class1
{
	
}
 //final class Final_as_class1
//{

//}  

 public class Final_as_class extends Final_as_class1  // compile time error
{  
	void run()
	{
		System.out.println("You cannot extend it, as it is FINAL CLASS");
	}  

	public static void main(String args[])
	{  
		Final_as_class FC= new Final_as_class();  
		FC.run();  
	}  
}  
