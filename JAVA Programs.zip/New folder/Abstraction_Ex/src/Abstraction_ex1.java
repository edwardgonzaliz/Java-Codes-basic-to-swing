class bank {
	private int accno;
	private String nam;
	private float balan;
	private double profit;
	private double badloan_npa_loss;

	void display_to_clerk() {
		System.out.println("Acc. No..." + accno);
		System.out.println("Name   ..." + nam);
		System.out.println("Balance..." + balan);
	}

}

public class Abstraction_ex1 {

	public static void main(String[] args) {
		bank s1 = new bank();
		s1.display_to_clerk();
	}

}
