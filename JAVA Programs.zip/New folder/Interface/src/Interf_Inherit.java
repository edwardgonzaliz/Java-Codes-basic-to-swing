//A class implements an interface, but one interface extends another interface.	
interface INTRF1
{  
	void DISP();  
}  
interface INTRF2 extends INTRF1
{  
	void Displ_1();  
}  
class Interf_Inherit implements INTRF2
{  
	public void DISP()
	{
		System.out.println("EXAMPLE OF INTERFACE");
	}  
	public void Displ_1()
	{
		System.out.println("EXAMPLE OF INHERITANCE");
	}  
	public static void main(String args[])
	{  
		Interf_Inherit ii = new Interf_Inherit();  
		ii.DISP();  
		ii.Displ_1();  
	}  
}  
