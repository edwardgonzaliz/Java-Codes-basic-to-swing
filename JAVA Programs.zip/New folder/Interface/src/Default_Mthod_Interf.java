//we can have method body in interface. But we need to make it default method.
interface Drawable_1
{  
	void draw();  
	default void msg()
	{
		System.out.println("default method");
	}  
}  
class Rectang implements Drawable_1
{  
	public void draw()
	{
		System.out.println("drawing rectangle");
	}  
}  
class Default_Mthod_Interf
{  
	public static void main(String args[])
	{  
		Drawable_1 d=new Rectang();  
		d.draw();  
		d.msg();  
	}
}  
