interface father1 
{	double ht = 10;
void height();	}
interface mother1 
{	double ht = 5.5;
void height();}
interface newinterface 
{		void display();	}
class child1 implements father1, mother1, newinterface 
{	double val, het;
public void height() 
{		het = ((father1.ht + mother1.ht) / 2);
System.out.println(het);	}
void add(double x) 
{		val = x;
System.out.println(val);	}
public void display() 
{		System.out.println(het + val);	}}
public class Interf_2 
{	public static void main(String[] args) 
{
	child1 ch = new child1();
	ch.height();
	ch.add(555);
	ch.display();
}}
