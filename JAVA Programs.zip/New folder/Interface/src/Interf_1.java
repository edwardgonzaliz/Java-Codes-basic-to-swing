interface father 
{
	double ht = 10; 
	void height();
}
interface mother 
{
	double ht = 5.5;
	void height();
}
class child implements father, mother 
{
	public void height() 
	{
		double het = ((father.ht + mother.ht) / 2);
		System.out.println(het);
	}}
public class Interf_1 
{	public static void main(String[] args) 
{		
	//child f1 = new child();
	father  f1= new child();	
	f1.height();	
	//mother m1 = new child();
	//m1.height();
	//father.ht=20; unable to modify as final and constant by default
}
}
