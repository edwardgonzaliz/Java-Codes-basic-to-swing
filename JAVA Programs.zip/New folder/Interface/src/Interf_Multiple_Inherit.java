//If a class implements multiple interfaces, or an interface extends multiple interfaces,
//it is known as multiple inheritance.
interface I_1{  
	void Disp();  
}  
interface I_2{  
	void Disp1();  
}  
class Interf_Multiple_Inherit implements I_1,I_2
{  
	public void Disp()
	{
		System.out.println("MULTIPLE");
	}  
	public void Disp1()
	{
		System.out.println("INHERITANCE");
	}  

	public static void main(String args[])
	{  
		//Interf_Multiple_Inherit m1 = new Interf_Multiple_Inherit();  
		I_1 m1 = new Interf_Multiple_Inherit();
		m1.Disp();  
		I_2 m2 = new Interf_Multiple_Inherit();
		m2.Disp1();  
	}  
}  