
interface Example
{  	
	int age=20;
	void show_EX();  		
}  
class Interf_0 implements Example
{  
	public void show_EX()
	{
		System.out.println("Implemented ...Abstract Method");
	}  		

	public static void main(String args[])
	{  
		//Interf_0 I1 = new Interf_0();
		Example I1 = new Interf_0(); 
		I1.show_EX(); 
		int b=Example.age;
		System.out.println("b is..."+b);
		//Example.age=30; //Not possible (acts as constant)
		
		
	}  
}  