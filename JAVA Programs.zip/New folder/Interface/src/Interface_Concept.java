/* An Interface is a specification of method prototype.
 * 
 * -All the methods of the Interface are public and abstract.
 * 
 * -Methods are public, as they should be available 
 * to 3rd party vendor to provide implementation
 * 
 * -abstract because their implementation is left for 3rd party.
 * 
 * -contains 0 or more abstract methods which are all public and 
 * abstract by default.
 * 
 * -Interface can have variables which are 
 * public, static and final by default.
 * 
 * -Means all variables of Interface are constant.
 * 
 * -No methods are private, protected.
 * 
 * -We can not create object to an Interface. 
 * But we can create reference of Interface type.
 * It is used to achieve abstraction.
   By interface, we can support the functionality of multiple inheritance.
   
   we can not define body of a method within interface, (as abstract), but we can make it by 
   default keyword.
   default void normalMethod() {
		System.out.println("This is a normal method in interface");
	}

 */

