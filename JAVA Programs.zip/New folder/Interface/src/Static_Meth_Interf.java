//we can have static method in interface. 
interface Shape
{  
	void comput();  
	static int cube(int x)
	{
		return x*x*x;
	}  
}  
class Rectang2 implements Shape
{  
	public void comput()
	{
		System.out.println("IMPLEMENTED.....");
	}  
}  

class Static_Meth_Interf
{  
	public static void main(String args[])
	{  
		Shape s1=new Rectang2();  
		s1.comput();  
		System.out.println(Shape.cube(4));  
	}
}  