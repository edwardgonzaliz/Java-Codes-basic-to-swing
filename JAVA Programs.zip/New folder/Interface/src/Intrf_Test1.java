
// Defining the first interface with an abstract, normal (default), and static method
interface MyInterface1 {
	// Abstract method
	void abstractMethod();

	// Normal (default) method
	default void normalMethod() {
		System.out.println("This is a normal method in interface");
	}

	// Static method
	static void staticMethod() {
		System.out.println("This is a static method in interface");
	}
}

// Defining another interface that extends the first interface and contains only a normal method
interface ExtendedInterface1 extends MyInterface1 {
	// Normal (default) method
	default void anotherNormalMethod() {
		System.out.println("This is another normal method in extended interface");
	}
}

// Implementing both interfaces in a class
class MyClass1 implements ExtendedInterface1 {
	// Implementing the abstract method from MyInterface
	public void abstractMethod() {
		System.out.println("Implementation of abstract method in MyClass");
	}
}

// Main class to test the program
public class Intrf_Test1 {
	public static void main(String[] args) {
		// Creating an object of MyClass
		MyClass1 obj = new MyClass1();

		// Calling the implemented abstract method
		obj.abstractMethod();

		// Calling the default methods from interfaces
		obj.normalMethod();
		obj.anotherNormalMethod();

		// Calling the static method from MyInterface
		MyInterface1.staticMethod();  // Static methods should be called via interface name
	}
}

