/*multiple inheritance is not supported in the case of class because of ambiguity. 
 However, it is supported in case of an interface because there is no ambiguity. 
 It is because its implementation is provided by the implementation class. */
interface I1
{  
	void Disp();  
}  
interface I2
{  
	void Disp();  
}  		  
class Interf_Multiple_Inherit_1 implements I1, I2
{  
	public void Disp()
	{
		System.out.println("Multiple Inheri...");
	}  
	public static void main(String args[])
	{  
		//Interf_Multiple_Inherit_1 mi = new Interf_Multiple_Inherit_1();  
		I1 mi = new Interf_Multiple_Inherit_1();
		mi.Disp();  
	}  
}  