class student2
{
	private int age;
	private String name;
	void input()
	{
		age=20;
		name="KIIT";
	}
	void display()
	{
		System.out.println("age is  " +age);
		System.out.println("name is " +name);
	}
}
 public class class_3 {

	public static void main(String[] args) {
		student2 s1=new student2();
		s1.input();
		s1.display();
	}
}
