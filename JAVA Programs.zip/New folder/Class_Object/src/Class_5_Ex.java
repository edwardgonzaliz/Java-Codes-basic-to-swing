/*WAP to print the area of a rectangle by creating a class named rect 
having two methods. First method named as 'setDim' takes length and breadth of rectangle
as parameters and the second method named as 'getArea' print the area of the rectangle. 
Length and breadth of rectangle are entered through keyboard.*/
import java.util.Scanner;
public class Class_5_Ex {
	double length;
	double breadth;

	void setDim() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length and breadth of a rectangle");
		length = sc.nextDouble();
		breadth = sc.nextDouble();
	}

	void getArea() {
		double area;
		area = length * breadth;
		System.out.println("age is  " + area);
	}

	public static void main(String[] args) {
		Class_5_Ex s1 = new Class_5_Ex();
		s1.setDim();
		s1.getArea();
	}
}