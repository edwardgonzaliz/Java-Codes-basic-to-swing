import java.util.*;
class student
{
	int age;        // Instance member declaration
	String name;   // Instance member declaration
	void input1()    
	{
		age=20;
		name="KIIT";		
	}
	void disp21()   
	{
		System.out.println("age is  " +age);
		System.out.println("name is " +name);
	}
}
public class class_1 {
	public static void main(String[] args) {
		student ss1=new student();    // ss1 object is created
		ss1.input1();                // Calling method
		ss1.disp21();               // Calling method
	}
}
