/*Create a class named 'Student' with String variable 'name' and 
 integer variable 'roll_no'. Assign the value of roll_no as '10' and
 that of name as "KIIT" by creating an object of the class Student.*/
class studenT_1 {
	int roll_no;
	String name;
}

public class Class_Ex_5_Ex_1 {
	public static void main(String[] args) {
		studenT_1 s1 = new studenT_1();
		s1.roll_no = 10;
		s1.name = "KIIT";
		System.out.println(" Roll No is " + s1.roll_no + "\n " + "Name is " + s1.name);
	}
}
