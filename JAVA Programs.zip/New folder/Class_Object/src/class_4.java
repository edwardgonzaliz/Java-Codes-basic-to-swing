
public class class_4 {
	int age;
	String name;
	void input()   // member function     input method
	{
		age=20;
		name="KIIT";
	}
	void display()      
	//int display()
	{
		System.out.println("age is  " +age);		
		System.out.println("name is " +name);
		//return age;
		
	}
	public static void main(String[] args) {
		class_4 s1=new class_4();
		s1.input();
		s1.display();
		//int ag=s1.display();
		
	}
}
