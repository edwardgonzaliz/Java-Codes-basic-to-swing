// Initialization of variable during declaration
class stud {
	private int age = 20;
	private String name = "KIIT";

	void display() {
		System.out.println("age is  " + age);
		System.out.println("name is " + name);
	}
}

public class class_4_1 {
	public static void main(String[] args) {
		stud s1 = new stud();
		// call the display method
		s1.display();
	}
}
