import java.util.Scanner;
class student1  // rectangle
{
	int age;   // double len; double bred; double area;  // int age=20;
	String name;
	
	void input()   // void setdimension    // student1(double le2,double br1) {len=le2;bred=br1 }
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the age and name of a student");
		age=sc.nextInt();
		name=sc.next();		
	}
	
	void display()    // int getarea() { area=l*b; return area;} //m called
	{
		System.out.println("age is  " +age);
		System.out.println("name is " +name);
	}
}
 public class class_2 {
	public static void main(String[] args) {
		student1 s1=new student1();
		s1.input();
		s1.display(); // int res=s1.getarea(); // calling m // Sys....(res);
	}
}
