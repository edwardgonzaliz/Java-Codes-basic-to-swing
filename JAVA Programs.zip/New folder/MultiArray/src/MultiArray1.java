import java.util.*;
public class MultiArray1 {
	public static void main(String[] args) {
		int i, j;
		Scanner sc = new Scanner(System.in);
		int a[][] = new int[2][3];
		System.out.println("enter the elements");
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				System.out.print(a[i][j] + "\t");				
			}
			System.out.println(" ");
		}
	}
}