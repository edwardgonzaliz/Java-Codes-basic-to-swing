import java.util.Scanner;

public class Matrix_Multiplication {

	public static void main(String[] args) {
		int i, j;
		Scanner sc = new Scanner(System.in);
		int a[][] = new int[2][3];
		int b[][] = new int[2][3];
		int res[][] = new int[2][2];
		System.out.println("enter the elements of 1st Matrix");
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		System.out.println("enter the elements of 2nd Matrix");
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				b[i][j] = sc.nextInt();
			}
		}
		System.out.println("Multiplication of elements in....");
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 2; j++) {
				res[i][j] = 0;
				for (int k = 0; k < 2; k++) {

					res[i][j] = res[i][j] + a[i][k] * b[k][j];
				}
			}
		}
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 2; j++) {
				System.out.print(res[i][j] + "\t");
			}
			System.out.println(" ");
		}

	}
}
// a=m*n   b=n*r    ab=m*r