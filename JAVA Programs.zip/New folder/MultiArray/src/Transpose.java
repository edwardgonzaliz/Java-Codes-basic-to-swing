import java.util.*;
public class Transpose {
	public static void main(String[] args) {
		int i, j, r, c;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the row size of the array");
		r = sc.nextInt();
		System.out.println("enter the column size of the array");
		c = sc.nextInt();
		int a[][] = new int[r][c];
		int b[][] = new int[c][r];
		System.out.println("enter the elements");
		for (i = 0; i < r; i++) {
			for (j = 0; j < c; j++) {
				a[i][j] = sc.nextInt();
				b[j][i] = a[i][j];
			}
		}
		for (i = 0; i < r; i++) {
			for (j = 0; j < c; j++) {
				System.out.print(a[i][j] + "\t");
			}
			System.out.println(" ");
		}
		System.out.println(" TRANSPOSE IS..........");
		for (i = 0; i < c; i++) {
			for (j = 0; j < r; j++) {
				System.out.print(b[i][j] + "\t");
			}
			System.out.println(" ");
		}

	}
}
