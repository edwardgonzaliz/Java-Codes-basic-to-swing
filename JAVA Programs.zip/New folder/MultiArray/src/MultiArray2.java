import java.util.Scanner;

public class MultiArray2 {
	public static void main(String[] args) {
		int i, j, r, c;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the row size of the array");
		r = sc.nextInt();
		System.out.println("enter the column size of the array");
		c = sc.nextInt();
		int a[][] = new int[r][c];

		System.out.println("enter the elements");
		for (i = 0; i < r; i++) {
			for (j = 0; j < c; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		for (i = 0; i < r; i++) {
			for (j = 0; j < c; j++) {
				System.out.print(a[i][j] + "\t");
			}
			System.out.println(" ");
		}
	}
}