import java.util.Scanner;

public class Matrix_Addition {

	public static void main(String[] args) {
		int i, j;
		Scanner sc = new Scanner(System.in);
		int a[][] = new int[2][3];
		int b[][] = new int[2][3];
		int res[][] = new int[2][3];
		System.out.println("enter the elements");
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		System.out.println("enter the elements");
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				b[i][j] = sc.nextInt();
			}
		}
		System.out.println("Addition of elements in....");
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				res[i][j] = a[i][j] + b[i][j];
			}
		}
		for (i = 0; i < 2; i++) {
			for (j = 0; j < 3; j++) {
				System.out.print(res[i][j] + "\t");
			}
			System.out.println( " ");
		}

	}

}
