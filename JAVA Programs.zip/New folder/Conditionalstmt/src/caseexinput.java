import java.util.Scanner;

public class caseexinput {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		int b,c=0;		
				
        
		switch(1)		
		{
		case 1:
			int k;
			System.out.println("Enter value for k and b");
			k=sc.nextInt();
			b=sc.nextInt();
			c=k+b;
			System.out.println("RSLT is"+c);
			//break;
		
		default:
				System.out.println("Invalid is "+c);
		}
	}

}
