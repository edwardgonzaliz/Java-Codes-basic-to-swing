import java.util.Scanner;
public class switch_month {
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);		
		int month;		
		System.out.println("Enter required Month");		
		month=sc.nextInt();		
		switch(month)
		{
		case 1:
			System.out.println("January");
			
		case 2:
			System.out.println("February");
			//break;
		case 3:
			System.out.println("March");
			//break;
		case 4:
			System.out.println("April");
			//break;
		default:
				System.out.println("Not a Valid month entered");
		}
	}
}
