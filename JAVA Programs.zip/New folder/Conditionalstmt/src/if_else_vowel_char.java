import java.util.Scanner;

public class if_else_vowel_char {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char ch;
		System.out.println("enter character");
		ch=sc.next().charAt(0);
		if(ch=='A' || ch=='a'|| ch=='e'||ch=='E')
			System.out.println("vowel");
		else
			System.out.println("Not vowel");

	}

}
