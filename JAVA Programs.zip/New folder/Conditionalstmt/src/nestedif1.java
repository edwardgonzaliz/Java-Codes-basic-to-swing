
public class nestedif1 {
	public static void main(String[] args) {
		int a, b, c;
		a=50;
		b=288;
		c=8;
		//if(a<b && a<c)
			//System.out.println("a is smallest");
		//else if(b<a && b<c)
			//System.out.println("b is smallest");
		//else
			//System.out.println("c is smallest");		
		if (a<b)
		{
			if(a<c)
			{
			      System.out.println("smallest is a = "+a);
			}
			else 
			{
			      System.out.println("smallest is"+c);
			}
		}
			else
			{
				if(b<c)
					System.out.println("smallest is"+b);
				else
					System.out.println("smallest is"+c);
			}
	}
}
