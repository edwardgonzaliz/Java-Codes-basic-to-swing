import java.util.Scanner;
public class switch_mark {
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);		
		int mark,m;		
		System.out.println("Enter u r Mark");		
		mark=sc.nextInt();
		m=mark/10;
		switch(m)
		{
		case 10:
		case 9:
			System.out.println("Outstanding");
			break;
		case 8:
			System.out.println("Excellent");
			break;
		default:
				System.out.println("Satisfactory");
		}
	}
}
