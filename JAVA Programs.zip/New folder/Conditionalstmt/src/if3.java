
public class if3 {

	public static void main(String[] args) {
		if(5>6)
			System.out.println("Hello");
		else
			System.out.println("Hello1");

	}

}
