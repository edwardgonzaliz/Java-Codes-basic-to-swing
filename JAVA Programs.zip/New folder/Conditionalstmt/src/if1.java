
public class if1 {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		if(a<b)
			System.out.println("Hello");
		if(a>b)
			System.out.println("Hello1");

	}

}
