import java.util.Scanner;
public class switch_vowel_char {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char ch;
		System.out.println("enter character");
		ch=sc.next().charAt(0);
		switch(ch)
		{
		case 'A':
		case 'a':
			System.out.println("Char ia a vowel");
			break;
		case 'E':
		case 'e':
			System.out.println("Char ia a vowel");
			break;		
		default:
				System.out.println("Not a vowel");
		}
	}
}
