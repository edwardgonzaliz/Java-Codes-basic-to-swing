import java.util.Scanner;
public class switch_day {
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		int day;		
		System.out.println("Enter u r day");		
		day=sc.nextInt();
		switch(day)		
		{
		case 1:
			System.out.println("Monday");
			break;
		case 2:
			System.out.println("Tuesday");
			break;
		default:
				System.out.println("Invalid ");
		}
	}
}
