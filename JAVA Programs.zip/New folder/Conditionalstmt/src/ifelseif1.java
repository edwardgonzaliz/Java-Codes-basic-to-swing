import java.util.Scanner;
public class ifelseif1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter required mark");
		int mark=sc.nextInt();
		if(mark>90)
			System.out.println("Outstanding");
		else if (mark>=80 && mark<90)
			System.out.println("Excellent ");
		else if(mark>=70 && mark<80)
			System.out.println("Good");
		else
			System.out.println("Satisfactory");
	}
}
		// int a=10;int b=20;
		// int c=a && b;
		// if (c>0)
		// System.out.println("Ex ");
		// int d=a & b;
		// if (d>0)
		// System.out.println("Exc ");
