
public class if2 {

	public static void main(String[] args) {
		//if(1)    // Error int to boolean not possible
			//System.out.println("Hello");
		if(true)
			System.out.println("Hello1");
		if(5<6)
			System.out.println("Hello2");

	}

}
