import java.util.Scanner;
public class Array_Return2 {
	static int[] sumarray(int a2[], int n1) {
		return a2;
		}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Array size u want");
		int n = sc.nextInt();
		int a[] = new int[n];
		System.out.println("Enter the Array Elements");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		int a3[] = sumarray(a, n);
		for (int i = 0; i < a3.length; i++) {
			System.out.println(a3[i]);
		}
	}
}
