import java.util.Scanner;
public class Array_Sum_Method{
	void sumarray(int a1[], int n1)	{
		int sum = 0;
		for (int i = 0; i < n1; i++) 
		{			sum = sum + a1[i];
		}
		System.out.println(sum);	}
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Array size u want");
		int n = sc.nextInt();
		int a[] = new int[n];
		System.out.println("Enter the Array Elements");
		for (int i = 0; i < n; i++) 
		{			a[i] = sc.nextInt();
		}
		Array_Sum_Method obj = new Array_Sum_Method();
		obj.sumarray(a, n);
	}}