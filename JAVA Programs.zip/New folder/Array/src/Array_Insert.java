
import java.util.Scanner;

public class Array_Insert {
	public static void main(String[] args) {
		int a[] = new int[20];
		// int a[]; //a=new int[20];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		System.out.println("Enter the elements");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the item to be inserted");
		int item;
		item = sc.nextInt();
		System.out.println("Enter the Position of element to be inserted");
		int pos = sc.nextInt();
		for (int i = n - 1; i >= pos; i--) {
			a[i + 1] = a[i];
		}
		a[pos] = item;
		System.out.println("The new Array is:");
		for (int i = 0; i <= n; i++) {
			System.out.println(a[i]);
		}
	}
}
