import java.util.Scanner;
public class BinarySearch {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n, l, u;
		int ele = 35;

		System.out.println("Enter size of n");
		n = sc.nextInt();
		int a[] = new int[n];
		System.out.println("Enter array elements");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		l = 0;		u = n - 1;		int mid = (l + u) / 2;
		while (l <= u) {

			if (ele == a[mid]) {
				System.out.println("  " + ele + "..." + mid);
				break;
			} else if (ele < a[mid]) {
				u = mid - 1;
			} else

				l = mid + 1;
			mid = (l + u) / 2;
		}
	}
}
