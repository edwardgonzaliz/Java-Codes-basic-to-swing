import java.util.Scanner;

class hello21 {
	public int[] reverseArray(int[] arr) {
		int i, j, n;
		n = arr.length;
		i = n - 1;
		int b[] = new int[n];
		for (i = n - 1, j = 0; i >= 0; i--, j++) {
			b[j] = arr[i];
		}
		return b;
	}
}

public class Array_Ret_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n2 = 5;
		int a[] = new int[n2];
		System.out.println("Enter the array elements");
		for (int i = 0; i < 5; i++) {
			a[i] = sc.nextInt();
		}
		hello21 h1 = new hello21();
		int c[] = h1.reverseArray(a);
		for (int i = 0; i < 5; i++) {
			System.out.println("Reverse elements are..." + c[i]);
		}
	}
}
