
//public class Array_Return {
//
//	public static int[] arrayMethod() {
//		int[] tempArray = { 1, 2, 3, 4 };
//		return tempArray;
//	}
//
//	public static void main(String[] args) {
//		int arr[] = arrayMethod();
//		for (int i : arr) {
//			System.out.println(i);
//		}
//	}
//}
public class Array_Return {

	public static int[] My_UD_Array() {
		int a1[]  = { 1, 2, 3, 4 };
		return a1;
	}

	public static void main(String[] args) {
		int a2[] = My_UD_Array();
		for (int i=1;i<=a2.length;i++) {
			System.out.println(i);
		}
	}
}