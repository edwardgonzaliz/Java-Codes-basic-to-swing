
import java.util.*;

public class Array_Reverse {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int r = n / 2;
		int end;
		end = n - 1;
		int a[] = new int[n];
		System.out.println("Enter the elements");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		for (int i = 0; i < r; i++) {
			int t;
			t = a[i];
			a[i] = a[end];
			a[end] = t;
			end--;
		}
		System.out.println("Print  the reversed  array");
		for (int i = 0; i < n; i++) {
			System.out.println(a[i]);
		}
	}

}
