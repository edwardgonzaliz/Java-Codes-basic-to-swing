
import java.util.*;
public class Array_Sum_AVG {
	public static void main(String[] args) {
		int a[]=new int[5];		
		int sum = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of the array");		
		System.out.println("enter the elements");
		for (int i = 0; i <5; i++)
		{
			a[i] = sc.nextInt();
			sum = sum + a[i];
		}
		float avg = (sum / a.length);
		System.out.println("sum is & avg is" + sum + "  " + avg);
	}
}