import java.util.*;
public class Array_Small_Large {
	public static void main(String[] args) {
		int big, small;
		Scanner sc = new Scanner(System.in);
	System.out.println("enter the size of the array");
		int size = sc.nextInt();
		int a[] = new int[size];
		System.out.println("enter the elements");
		for (int i = 0; i < size; i++)
		{
			a[i] = sc.nextInt();
		}
		big = small = a[0];
		for (int i = 0; i < a.length; i++) 
		{
			if (small > a[i])
				small = a[i];
			if (big < a[i])
				big = a[i];
}System.out.println("big & small" + big + " " + small);
	}}