
import java.util.*;

public class Array_Rev_2ndArray {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i, j;
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int a[] = new int[n];
		int b[] = new int[n];
		System.out.println("Enter the elements into the array");
		for (i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		for (i = n - 1, j = 0; i >= 0; i--, j++) {
			b[j] = a[i];
		}
		System.out.println("Reversed Array is");
		for (j = 0; j < n; j++) {
			System.out.println(b[j]);
		}

	}
}
