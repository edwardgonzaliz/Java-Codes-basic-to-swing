import java.util.Scanner;
public class Bubble_Sort {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int size = sc.nextInt();
		int a[] = new int[size];
		System.out.println("enter the elements");
		for (int i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();		}
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < (size - i) - 1; j++) {
				if (a[j] > a[j + 1]) {
					int temp = a[j];
					a[j] = a[j + 1];
					a[j + 1] = temp;
				}			}		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);		}	}
}