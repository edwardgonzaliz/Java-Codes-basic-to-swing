
public class Array_2 {

	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4, 5 };
		int i;
		for (i = 0; i < 7; i++)
			System.out.println(a[i]);

	}

}