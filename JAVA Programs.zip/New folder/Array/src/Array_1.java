
public class Array_1 {

	public static void main(String[] args) {
		int x=5;
		int a[]=new int[x];
		a[1]=10;
		System.out.println(a[1]);

	}

}
