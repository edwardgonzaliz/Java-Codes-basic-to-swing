import java.util.Scanner;
public class Number_present_Array {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cnt = 0;
		int num = 5;
		int a[] = new int[6];
		System.out.println("Enter the elements");
		for (int i = 0; i < 6; i++) {
			a[i] = sc.nextInt();
		}
		for (int i = 0; i < 6; i++) {

			if (a[i] == num) {
				cnt++;
			}
		}
		System.out.println(cnt);
	}
}
