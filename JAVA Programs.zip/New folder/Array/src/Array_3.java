
public class Array_3 {
	public static void main(String[] args) {
		int i;
		int c[] = new int[5];
		for (i = 0; i < 5; i++)
			System.out.println(c[i]);
	}
}
