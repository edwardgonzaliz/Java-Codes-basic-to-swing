	class AOA_1 {
	    String name;
	    int age;
	    String grade;

	   AOA_1(String name, int age, String grade) {
	        this.name = name;
	        this.age = age;
	        this.grade = grade;
	    }	    
	    void displayInfo() {
	        System.out.println("Name: " + name + ", Age: " + age + ", Grade: " + grade);
	    }
	}
	public class ArrayOfObj_1  {
	    public static void main(String[] args) {
	        // Declare and initialize an array of Student objects
	    	AOA_1 AR[] = new AOA_1[3];

	        // Create and assign Student objects
	        AR[0] = new AOA_1("AAAA", 10, "O");
	        AR[1] = new AOA_1("BBBB", 20, "E");
	        AR[2] = new AOA_1("CCCC", 30, "A");

	        // Display information for each student
	        System.out.println("Student Information:");
	        for (int i = 0; i < AR.length; i++) {
	            AR[i].displayInfo();
	        }
	    }
	}