
import java.util.Scanner;

class bse {
	void bs(int a[], int n) {
		int mid;
		int ele = 35;
		int l, u;
		l = 0;
		u = n - 1;
		mid = (l + u) / 2;
		while (l <= u) {

			if (ele == a[mid]) {
				System.out.println("  " + ele + "" + mid);
				break;
			} else if (ele < a[mid]) {
				u = mid - 1;
			} else

				l = mid + 1;
			mid = (l + u) / 2;

		}

	}
}

public class BinarySearch_Method {

	public static void main(String[] args) {
		bse b1 = new bse();
		Scanner sc = new Scanner(System.in);
		int n, l, u;
		System.out.println("Enter size of n");
		n = sc.nextInt();
		int a[] = new int[n];
		System.out.println("Enter array elements");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		b1.bs(a, n);

	}

}
