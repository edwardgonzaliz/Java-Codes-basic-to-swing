import java.util.Scanner;

public class Array1 {
	public static void main(String[] args) {
		int a[] = new int[10];
		System.out.println(a[8]);
		System.out.println(a[6]);
		System.out.println(a[3]);
		System.out.println(a[9]);

	}

}
