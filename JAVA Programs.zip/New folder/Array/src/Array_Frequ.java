import java.util.Scanner;
public class Array_Frequ {
	public static void main(String[] args) {
		int cnt, i;
		Scanner sc = new Scanner(System.in);
		int a[] = new int[6];
		for (i = 0; i < 6;i++) {
			a[i] = sc.nextInt();
		}
		for (i = 0; i < 6;) 
		{
			cnt = 1;
			for (int j = i + 1; j < 6; j++) 
			{
				if (a[i] == a[j])

					cnt++;
				else
					break;
			}
			System.out.println(cnt);
			//i = i + cnt;
		}
	}

}
