import java.util.Scanner;
class AOA_2 {
	String name;
	int age;
	String grade;

	void inputDetails() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter name: ");
		name = scanner.nextLine();
		System.out.print("Enter age: ");
		age = scanner.nextInt();
		scanner.nextLine();  // Consume the newline character
		System.out.print("Enter grade: ");
		grade = scanner.nextLine();
	}

	void displayInfo() {
		System.out.println("Name: " + name + ", Age: " + age + ", Grade: " + grade);
	}
}
public class ArrayOfObj_2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter number of students: ");
		int n = scanner.nextInt();
		scanner.nextLine();  // Consume the newline character

		AOA_2 AR2[] = new AOA_2[n];

		for (int i = 0; i < n; i++) {
			AR2[i] = new AOA_2();  // Create a new Student object
			System.out.println("Enter details for student " + (i + 1) + ":");
			AR2[i].inputDetails();
		}

		System.out.println("\nStudent Information:");
		for (int i = 0; i < n; i++) {
			AR2[i].displayInfo();
		}
	}
}