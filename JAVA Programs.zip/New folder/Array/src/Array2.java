import java.util.Scanner;

public class Array2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int a[] = new int[10];
		int sum = 0;
		System.out.println("enter the elements");
		for (int i = 0; i < 10; i++) {
			a[i] = sc.nextInt();
			sum = sum + a[i];
		}
		float avg = (sum / 10);
		System.out.println("sum is & avg is" + sum + "  " + avg);
	}

}
