class student {
	int age, id;
	student(int x, int y) {
		age = x;
		id = y;
	}
	void display() {
		System.out.println("Age & Id is " + age + " " + id);
	}
}
public class Array_of_Object {
	public static void main(String[] args) {
		student s1[] = new student[3];
		s1[0] = new student(20, 100);
		s1[0].display();
		s1[1] = new student(21, 200);
		s1[1].display();
		s1[2] = new student(22, 300);
		s1[2].display();
//		for(int i=0;i<3;i++)
//		{
//			s1[i].display();
//		}

	}

}
