import java.util.Scanner;

public class Array_Even_Odd {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cnt_even = 0;
		int cnt_odd = 0;
		int num = 5;
		int a[] = new int[6];
		System.out.println("Enter the elements");
		for (int i = 0; i < 6; i++) {
			a[i] = sc.nextInt();
		}
		for (int i = 0; i < 6; i++) 
		{

			if (a[i] %2==0) 
			{
				cnt_even++;
			}
				else
				{
					cnt_odd++;
				}
			}		
		System.out.println("Ans is "+cnt_even+ " " + cnt_odd);
	}
}