
import java.util.*;

public class Array_Delete {
	public static void main(String[] args) {
		int a[] = new int[20];
		// int a[]; //a=new int[20];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		System.out.println("Enter the elements");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("Enter the Position of element to be deleted");
		int pos = sc.nextInt();
		for (int i = pos; i < n; i++) {
			a[i] = a[i + 1];
		}
		n = n - 1;
		System.out.println("The new Array is:");
		for (int i = 0; i < n; i++) {
			System.out.println(a[i]);
		}
	}
}
