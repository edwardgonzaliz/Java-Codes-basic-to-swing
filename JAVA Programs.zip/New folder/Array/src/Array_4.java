
public class Array_4 {
	public static void main(String[] args) {
		int i;
		int b[] = new int[] { 1, 2, 3, 4, 5 };
		for (i = 0; i < 7; i++)
			System.out.println(b[i]);
	}
}
