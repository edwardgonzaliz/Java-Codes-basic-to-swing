import java.util.Scanner;

public class Array3 {
	public static void main(String[] args) {
		// int a[]=new int[5];
		// int a[];
		// a=new int[10];
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int size = sc.nextInt();		
		int a[] = new int[size];
		int sum = 0;
		System.out.println("enter the elements");
		for (int i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
			sum = sum + a[i];
		}
		float avg = (sum / a.length);
		System.out.println("sum is & avg is" + sum + "  " + avg);
	}
}
