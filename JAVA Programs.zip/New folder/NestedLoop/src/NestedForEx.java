
public class NestedForEx {

	public static void main(String[] args) {
		int cnt=0;
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<i;j++)
			{
				System.out.print(cnt++);				
			}
			System.out.println();
		}


	}

}
