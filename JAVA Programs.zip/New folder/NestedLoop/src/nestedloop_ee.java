
public class nestedloop_ee {

	public static void main(String[] args) {
		for(int i=1; i<=5;i++) // outer loop   no of rows
		{
			for(int j=1; j<=5;j++) //inner loop  no of columns 
			{
				System.out.print("* ");				
			}
			System.out.println();				
		}

	}

}
