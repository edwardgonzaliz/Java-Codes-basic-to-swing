
public class Nest_ex1 {

	public static void main(String[] args) {
		for(int i=1;i<=5;i++)       // Outer for loop          number of rows
		{
			for(int j=1;j<=5;j++)   // Inner for loop          total value row
			{
				System.out.print(" * ");				
				
			}
			System.out.println();
		}

	}

}
